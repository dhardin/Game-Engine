tiled-xna
=========

C# and XNA implementation of Tiled map reader. http://www.mapeditor.org/

Drawing the map is specific to XNA, but reading the Tiled file format should be useful for any framework using C#.

On the XBox360, GZip compression requires a class not present in the 360's version of the .NET runtime. See Releases for more information.