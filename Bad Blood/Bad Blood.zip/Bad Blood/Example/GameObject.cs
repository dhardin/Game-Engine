﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using Squared.Tiled;
using PolygonIntersection;
using System.IO;
using System.Collections;
using C3.XNA;

namespace Game
{
    public class GameObject
    {
        /*
        GameObject
     	    v2 position
            v2 velocity
            int health
         */

        // Position of the GameObject relative to the upper left side of the screen
        public Vector2 Position;
        public Vector2 Velocity;
        public float Rotation;
        public Vector2 Orgin;
        public int Layer;
        public int Height;
        public int Width;
        public Texture2D Texture;
        public Polygon Poly;
        public Rectangle Rect;
        private const float SIZE_MOD = 0.4f;
        private Vector2 mousePosition;
        private List<Projectile> Projectiles = new List<Projectile>();
       
        public void Initialize(Vector2 position, float rotation, int layer, ContentManager Content)
        {
            this.Texture = Content.Load<Texture2D>("Textures/player");
            this.Position = position;
            this.Layer = layer;
            this.Height = (int)(Math.Min(this.Texture.Height, this.Texture.Width) * SIZE_MOD);
            this.Width = (int)(Math.Min(this.Texture.Height, this.Texture.Width) * SIZE_MOD);
            this.Poly = new Polygon();
            //this.Rect = new Rectangle((int)this.Position.X, (int)this.Position.Y, this.Width, this.Height);  
            this.Poly.Points.Clear();
            Vector2 temp = new Vector2(Width/2, Height / 2);
            this.Poly.Points.Add(this.Position - temp);
            this.Poly.Points.Add(new Vector2(this.Position.X + this.Width, this.Position.Y) - temp);
            this.Poly.Points.Add(new Vector2(this.Position.X + this.Width, this.Position.Y + this.Height) - temp);
            this.Poly.Points.Add(new Vector2(this.Position.X, this.Position.Y + this.Height) - temp);
            this.Poly.BuildEdges();
            //findOrgin();
        }


        public void Update(GameTime gameTime)
        {
            
            this.Position += this.Velocity;
            for (int i = 0; i < Poly.Points.Count; i++)
                Poly.Points[i] += this.Velocity;
           // findOrgin();
            //this.Orgin += this.Velocity;
            this.Rotate();
           // this.Velocity = new Vector2(0,0);
            //this.Rotation = 0;
            for (int i = 0, mod = 0; i < Projectiles.Count - mod; i++)
            {
               Projectiles[i].myProjectile.Update(gameTime);
              
                if (Projectiles[i].myProjectile.CurrentFrameAnimation.CurrentFrame.Equals(Projectiles[i].myProjectile.CurrentFrameAnimation.FrameCount - 1))
                {
                    Projectiles.RemoveAt(i);
                    mod++;

                }
            }
            
        }

        //      private void UpdatePlayer(GameTime gameTime)
        //{

        //    //reset rotation angle if it is greater than 2PI radians or less than 0 radians
        //    player.RotationAngle = MathHelper.WrapAngle(player.RotationAngle);
        //    // Get Thumbstick Controls
        //    player.Position.X += currentGamePadState.ThumbSticks.Left.X * playerMoveSpeed;
        //    player.Position.Y -= currentGamePadState.ThumbSticks.Left.Y * playerMoveSpeed;

        //    // calculate the current forward vector (make it negative so we turn in the correct direction)
        //    Vector2 forward = new Vector2((float)Math.Sin(player.RotationAngle),
        //        (float)Math.Cos(player.RotationAngle));
        //    Vector2 right = new Vector2(-1 * forward.Y,forward.X);//vector that is at a right angle (+PI/2) to the vector that you're moving in

        //    float elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;

        //    // calculate the new forward vector with the left stick
        //    if (currentGamePadState.ThumbSticks.Left.LengthSquared() > 0f)
        //    {
        //        // change the direction 
        //        Vector2 wantedForward = Vector2.Normalize(currentGamePadState.ThumbSticks.Left);
        //        //find the difference between our current vector and wanted vector using the dot product
        //        float angleDiff = (float)Math.Acos(
        //            Vector2.Dot(wantedForward, forward));

        //        //check the angle between the right angle from the current vector and wanted.  Adjust rotation direction accordingly
        //        float facing;
        //        if (Vector2.Dot(wantedForward, right) > 0f)
        //        {
        //            //rotate towards right angle first
        //            facing = -1.0f;
        //        }
        //        else
        //        {
        //            //rotate towards the wanted angle since it is closer
        //            facing = 1.0f;
        //        }
               
        //        //if we have an acceptable change in direction that is not too small
        //        if (angleDiff > (Math.PI/20))
        //        {
        //            player.RotationAngle += facing * Math.Min(angleDiff, elapsed *
        //                player.RotationRadiansPerSecond);
        //        }

        //        // add velocity
        //        player.Velocity += currentGamePadState.ThumbSticks.Left * (elapsed * player.FullSpeed);
        //        if (player.Velocity.Length() > player.VelocityMaximum)
        //        {
        //            player.Velocity = Vector2.Normalize(player.Velocity) *
        //                player.VelocityMaximum;
        //        }
        //    }
        //    //currentGamePadState.ThumbSticks.Left = Vector2.Zero;

        //    // apply drag to the velocity
        //    player.Velocity -= player.Velocity * (elapsed * player.DragPerSecond);
        //    if (player.Velocity.LengthSquared() <= 0f)
        //    {
        //        player.Velocity = Vector2.Zero;
        //    }
        //    // Windows Phone Controls
        //    while (TouchPanel.IsGestureAvailable)
        //    {
        //        GestureSample gesture = TouchPanel.ReadGesture();
        //        if (gesture.GestureType == GestureType.FreeDrag)
        //        {
        //            player.Position += gesture.Delta;
        //        }
        //    }


        //    // Use the Keyboard / Dpad
        //    if (currentKeyboardState.IsKeyDown(Keys.Left) ||
        //    currentGamePadState.DPad.Left == ButtonState.Pressed)
        //    {
        //        player.Position.X -= playerMoveSpeed;
        //    }
        //    if (currentKeyboardState.IsKeyDown(Keys.Right) ||
        //    currentGamePadState.DPad.Right == ButtonState.Pressed)
        //    {
        //        player.Position.X += playerMoveSpeed;
        //    }
        //    if (currentKeyboardState.IsKeyDown(Keys.Up) ||
        //    currentGamePadState.DPad.Up == ButtonState.Pressed)
        //    {
        //        player.Position.Y -= playerMoveSpeed;
        //    }
        //    if (currentKeyboardState.IsKeyDown(Keys.Down) ||
        //    currentGamePadState.DPad.Down == ButtonState.Pressed)
        //    {
        //        player.Position.Y += playerMoveSpeed;
        //    }

        //    // Make sure that the player does not go out of bounds
        //    player.Position.X = MathHelper.Clamp(player.Position.X, 0, GraphicsDevice.Viewport.Width - player.Width);
        //    player.Position.Y = MathHelper.Clamp(player.Position.Y, 0, GraphicsDevice.Viewport.Height - player.Height);

        //    // Fire in indicated right thumbstick direction
        //    if (currentGamePadState.ThumbSticks.Right.LengthSquared() > 0.0f && (gameTime.TotalGameTime - previousFireTime > fireTime))
        //    {
        //        // Reset our current time
        //        previousFireTime = gameTime.TotalGameTime;

        //        // change the fire direction 
        //        Vector2 wantedForward = Vector2.Normalize(currentGamePadState.ThumbSticks.Right);
        //        Vector2 forwardVector = new Vector2(1, 0);
        //        //check the angle between the right angle from the current vector and wanted.  Adjust rotation direction accordingly
              
        //        float angleDiff = (float)Math.Acos(Vector2.Dot(wantedForward, forwardVector));
        //        //quadrant II
        //        if (wantedForward.Y > 0)
        //        {
        //            angleDiff *= -1;
        //        }
            
        //        // Add the projectile but rotate it and fire in the direction indicated by the right analog stick
        //        //AddProjectile(player.Position + new Vector2(player.Width / 2, 0), angleDiff);
        //        // Play the laser sound
        //        //laserSound.Play();
        //    }

        //    // reset score if player health goes to zero
        //    //if (player.Health <= 0)
        //    //{
        //    //    player.Health = 100;
        //    //    score = 0;
        //    //}
        //}
        //}

        public void Draw(SpriteBatch batch, Vector2 offset, Vector2 viewportPosition, float opacity, int width, int height)
        {

            //batch.Draw(this.Texture, this.Position, Color.White);
            batch.Draw(this.Texture, this.Position, null, Color.White, this.Rotation, new Vector2(this.Texture.Width * 0.26f, this.Texture.Height/2), SIZE_MOD, SpriteEffects.None, 0);
            for (int i = 0; i < Poly.Points.Count; i++)
                Primitives2D.DrawLine(batch, Poly.Points[i%4], Poly.Points[(i+1)%4], Color.LightPink, 1f);
            for (int i = 0, mod = 0; i < Projectiles.Count - mod; i++)
            {
                Vector2 displacement = new Vector2(
                    (float)(this.Position.X + (this.Texture.Width - this.Width)* Math.Cos(Rotation)), (float)(this.Position.Y + (this.Texture.Width - this.Width)* Math.Sin(Rotation)));
                Projectiles[i].myProjectile.Draw(batch, (int)displacement.X, (int)displacement.Y, Rotation);
               
            }
            

            //draw mouse crosshair
            Primitives2D.DrawLine(batch, this.Position, mousePosition, Color.Red, 0.6f);
            //Primitives2D.DrawLine(batch, new Vector2(this.Rect.X, this.Rect.Y), new Vector2(this.Rect.X + this.Width, this.Rect.Y), Color.LightBlue);
            //Primitives2D.DrawLine(batch, new Vector2(this.Rect.X + this.Width, this.Rect.Y), new Vector2(this.Rect.X + this.Width, this.Rect.Y + this.Height), Color.LightBlue);
            //Primitives2D.DrawLine(batch, new Vector2(this.Rect.X + this.Width, this.Rect.Y + this.Height), new Vector2(this.Rect.X, this.Rect.Y + this.Height), Color.LightBlue);
            //Primitives2D.DrawLine(batch, new Vector2(this.Rect.X, this.Rect.Y + this.Height), new Vector2(this.Rect.X, this.Rect.Y), Color.LightBlue);
            //batch.Draw(this.Texture, new Vector2(this.Rect.X, this.Rect.Y), null, Color.White, 0f,this.Orgin, SIZE_MOD, SpriteEffects.None, 1f);
            //batch.Draw(this.Texture, this.Position,  null,  Color.White,this.Rotation, new Vector2(this.Rect.Center.X, this.Rect.Center.Y),1.0f, SpriteEffects.None, 0f);
        }

        public void Rotate()
        {

            MouseState mouse = Mouse.GetState();
            mousePosition = new Vector2(mouse.X, mouse.Y);

            Vector2 direction = mousePosition - this.Position;
            direction.Normalize();

            this.Rotation = (float)Math.Atan2(
                          (double)direction.Y,
                          (double)direction.X);

            //for (int i = 0; i < Poly.Points.Count; i++)
            //{
                
            //    //this.Poly.Points[i] = rotate_vector(this.Position, this.Rotation, this.Position);
            //}

        }

        Vector2 rotate_vector(Vector2 orgin, float angle, Vector2 p)
        {
            float s = (float)Math.Sin((double)angle);
            float c = (float)Math.Cos((double)angle);

            // translate point back to origin:
            p.X -= orgin.X;
            p.Y -= orgin.Y;

            // Counterclockwise
            float xnew = p.X * c - p.Y * s;
            float ynew = p.X * s + p.Y * c;
            // Clockwise
            //float xnew = p.X * c + p.Y * s;
            //float ynew = -p.Y * s + p.Y * c;

            // translate point back:
            p.X = xnew + orgin.X;
            p.Y = ynew + orgin.Y;

            return p;
        }

        private void findOrgin()
        {
            float minX = Poly.Points[0].X;
            float minY = Poly.Points[0].Y;
            float maxX = Poly.Points[0].X;
            float maxY = Poly.Points[0].Y;

            for (int i = 1; i < Poly.Points.Count; i++)
            {
                if (Poly.Points[i].X < minX)
                    minX = Poly.Points[i].X;
                else if (Poly.Points[i].X > maxX)
                    maxX = Poly.Points[i].X;

                if (Poly.Points[i].Y < minY)
                    minY = Poly.Points[i].Y;
                else if (Poly.Points[i].Y > maxY)
                    maxY = Poly.Points[i].Y;
            }

            //since we have our min and max x & y values, we can calculate the orgin
            this.Orgin = new Vector2((maxX - minX) / 2, (maxY - minY) / 2);
        }

        public void Attack(ContentManager Content)
        {
            Projectiles.Add(new Projectile(Content));
        }
    }
}