﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Game
{
    class Projectile : GameObject
    {
        
        public Texture2D projectile;
        public SpriteAnimation myProjectile;
        public void Initialize(ContentManager Content)
         {
             projectile = Content.Load<Texture2D>(@"Textures/gun_shot");
             myProjectile = new SpriteAnimation(projectile);
             myProjectile.AddAnimation("shot", 0, 0, 63, 16, 2, 0.1f);
             myProjectile.CurrentAnimation = "shot";
         }
         public Projectile(ContentManager Content)
         {
             Initialize(Content);
         }

    }
}