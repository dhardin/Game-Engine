﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;


namespace Game
{
    class Player : GameObject
    {
    }
}
        // Animation representing the player
//        public Texture2D PlayerTexture;

//        //Player's orignal orgin
//        private Vector2 origin;

//        //Current rotation of player
//        private float rotationAngle;

//        //full speed of the ship
//        float fullSpeed = 320f;

//        //maximum length of velocity of ship
//        float velocityMaximum;

//        float dragPerSecond = 0.9f;

//        //number of radians the ship can turn when left stick is pressed all the way
//        float rotationRadiansPerSecond;

//        // State of the player
//        public bool Active;

//        // Amount of hit points that player has
//        public int Health;
//        Vector2 velocity;
        
//        // Get the width of the player ship
//        public int Width
//        {
//            get { return PlayerTexture.Width; }
//        }
  
//        public Vector2 Origin
//        {
//            get { return origin;}
//            set { origin = value;}
//        }
//        public float RotationAngle
//        {
//            get { return rotationAngle; }
//            set { rotationAngle = value; }
//        }

//        // Get the height of the player ship
//        public int Height
//        {
//            get { return PlayerTexture.Height; }
//        }

//        public float RotationRadiansPerSecond
//        {
//            get { return rotationRadiansPerSecond; }
//            set { rotationRadiansPerSecond = value; }
//        }

//        public float FullSpeed
//        {
//            get { return fullSpeed; }
//            set { fullSpeed = value; }
//        }

//        public float VelocityMaximum
//        {
//            get { return velocityMaximum; }
//            set { velocityMaximum = value; }
//        }

//        public float DragPerSecond
//        {
//            get { return dragPerSecond; }
//            set { dragPerSecond = value; }
//        }

//        public Vector2 Velocity
//        {
//            get { return velocity; }
//            set
//            {
//                if ((value.X == Single.NaN) || (value.Y == Single.NaN))
//                {
//                    throw new ArgumentException("Velocity was NaN");
//                }
//                velocity = value;
//            }
//        }
//        public void Initialize(Texture2D texture, Vector2 position)
//        {
//            PlayerTexture = texture;

//            // Set the starting position of the player around the middle of the screen and to the back
//            Position = position;

//            //set starting rotation angle of player
//            rotationAngle = 0f;

//            //max rotation speed of ship with left joystick
//            rotationRadiansPerSecond = 15f;

//            //full speed of ship
//            fullSpeed = 320f;

//            //sourceRectangle = new Rectangle((int)this.Position.X, (int)this.Position.Y, this.Width, this.Height);

//            velocityMaximum = 320f;

//            dragPerSecond = 0.9f;

//            velocity = Vector2.Zero;

//            //set orgin position of player
//            origin.X = texture.Width / 2;
//            origin.Y = texture.Height / 2;

//            // Set the player to be active
//            Active = true;

//            // Set the player health
//            Health = 100;
//        }

//        // Draw the player
//        public void Draw(SpriteBatch spriteBatch)
//        {
//            spriteBatch.Draw(PlayerTexture, Position, null, Color.White, RotationAngle,
//                Origin, 1.0f, SpriteEffects.None, 0f);
//        }
    

//        private void UpdatePlayer(GameTime gameTime)
//        {

//            //reset rotation angle if it is greater than 2PI radians or less than 0 radians
//            RotationAngle = MathHelper.WrapAngle(RotationAngle);
//            // Get Thumbstick Controls
//            Position.X += currentGamePadState.ThumbSticks.Left.X * playerMoveSpeed;
//            Position.Y -= currentGamePadState.ThumbSticks.Left.Y * playerMoveSpeed;

//            // calculate the current forward vector (make it negative so we turn in the correct direction)
//            Vector2 forward = new Vector2((float)Math.Sin(RotationAngle),
//                (float)Math.Cos(RotationAngle));
//            Vector2 right = new Vector2(-1 * forward.Y, forward.X);//vector that is at a right angle (+PI/2) to the vector that you're moving in

//            float elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;

//            // calculate the new forward vector with the left stick
//            if (currentGamePadState.ThumbSticks.Left.LengthSquared() > 0f)
//            {
//                // change the direction 
//                Vector2 wantedForward = Vector2.Normalize(currentGamePadState.ThumbSticks.Left);
//                //find the difference between our current vector and wanted vector using the dot product
//                float angleDiff = (float)Math.Acos(
//                    Vector2.Dot(wantedForward, forward));

//                //check the angle between the right angle from the current vector and wanted.  Adjust rotation direction accordingly
//                float facing;
//                if (Vector2.Dot(wantedForward, right) > 0f)
//                {
//                    //rotate towards right angle first
//                    facing = -1.0f;
//                }
//                else
//                {
//                    //rotate towards the wanted angle since it is closer
//                    facing = 1.0f;
//                }

//                //if we have an acceptable change in direction that is not too small
//                if (angleDiff > (Math.PI / 20))
//                {
//                    RotationAngle += facing * Math.Min(angleDiff, elapsed *
//                        RotationRadiansPerSecond);
//                }

//                // add velocity
//                Velocity += currentGamePadState.ThumbSticks.Left * (elapsed * FullSpeed);
//                if (Velocity.Length() > VelocityMaximum)
//                {
//                    Velocity = Vector2.Normalize(Velocity) *
//                        VelocityMaximum;
//                }
//            }
//            //currentGamePadState.ThumbSticks.Left = Vector2.Zero;

//            // apply drag to the velocity
//            Velocity -= Velocity * (elapsed * DragPerSecond);
//            if (Velocity.LengthSquared() <= 0f)
//            {
//                Velocity = Vector2.Zero;
//            }
//            // Windows Phone Controls
//            while (TouchPanel.IsGestureAvailable)
//            {
//                GestureSample gesture = TouchPanel.ReadGesture();
//                if (gesture.GestureType == GestureType.FreeDrag)
//                {
//                    Position += gesture.Delta;
//                }
//            }


//            // Use the Keyboard / Dpad
//            if (currentKeyboardState.IsKeyDown(Keys.Left) ||
//            currentGamePadState.DPad.Left == ButtonState.Pressed)
//            {
//                Position.X -= playerMoveSpeed;
//            }
//            if (currentKeyboardState.IsKeyDown(Keys.Right) ||
//            currentGamePadState.DPad.Right == ButtonState.Pressed)
//            {
//                Position.X += playerMoveSpeed;
//            }
//            if (currentKeyboardState.IsKeyDown(Keys.Up) ||
//            currentGamePadState.DPad.Up == ButtonState.Pressed)
//            {
//                Position.Y -= playerMoveSpeed;
//            }
//            if (currentKeyboardState.IsKeyDown(Keys.Down) ||
//            currentGamePadState.DPad.Down == ButtonState.Pressed)
//            {
//                Position.Y += playerMoveSpeed;
//            }

//            // Make sure that the player does not go out of bounds
//            Position.X = MathHelper.Clamp(Position.X, 0, GraphicsDevice.Viewport.Width - Width);
//            Position.Y = MathHelper.Clamp(Position.Y, 0, GraphicsDevice.Viewport.Height - Height);

//            //// Fire in indicated right thumbstick direction
//            //if (currentGamePadState.ThumbSticks.Right.LengthSquared() > 0.0f && (gameTime.TotalGameTime - previousFireTime > fireTime))
//            //{
//            //    // Reset our current time
//            //    previousFireTime = gameTime.TotalGameTime;

//            //    // change the fire direction 
//            //    Vector2 wantedForward = Vector2.Normalize(currentGamePadState.ThumbSticks.Right);
//            //    Vector2 forwardVector = new Vector2(1, 0);
//            //    //check the angle between the right angle from the current vector and wanted.  Adjust rotation direction accordingly

//            //    float angleDiff = (float)Math.Acos(Vector2.Dot(wantedForward, forwardVector));
//            //    //quadrant II
//            //    if (wantedForward.Y > 0)
//            //    {
//            //        angleDiff *= -1;
//            //    }

//            //    // Add the projectile but rotate it and fire in the direction indicated by the right analog stick
//            //    AddProjectile(Position + new Vector2(Width / 2, 0), angleDiff);
//            //    // Play the laser sound
//            //    laserSound.Play();
//            //}

//            //// reset score if player health goes to zero
//            //if (Health <= 0)
//            //{
//            //    Health = 100;
//            //    score = 0;
//            //}
//        }
//    }
//}
